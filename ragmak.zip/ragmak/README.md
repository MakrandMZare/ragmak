# 🧠 ragmak — Minimal Spring Boot RAG Demo with Spring AI

This project demonstrates a **Retrieval-Augmented Generation (RAG)** flow using **Spring Boot** and **Spring AI**, designed for fast prototyping and consulting reuse. It embeds sample documents, performs similarity search, and constructs prompts for question answering via LLMs.

---

## 🚀 Features

- **REST Endpoint**: `POST /ask` — accepts `{ "question": "..." }`
- **Spring AI Integration**:
  - `ChatClient` for LLM responses
  - `EmbeddingClient` for vector embeddings
- **In-Memory Vector Store**:
  - Hardcoded sample documents
  - Cosine similarity search
- **Prompt Construction**:
  - Retrieved context injected into a simple prompt template
- **Modular Design**:
  - Clear separation of controller, service, store, and model
  - Easily extensible for file uploads, persistent stores, or advanced templates

---

## 📦 Tech Stack

| Layer        | Technology         |
|--------------|--------------------|
| Framework    | Spring Boot 3.4.x  |
| AI Provider  | Spring AI (OpenAI) |
| Embeddings   | Spring AI EmbeddingClient |
| LLM Chat     | Spring AI ChatClient |
| Storage      | In-memory vector store |
| API          | REST (JSON)        |

---

## 📁 Project Structure

src/main/java/com/example/ragmak
├── RagDemoApplication.java         # Main entry point
├── controller/AskController.java  # REST endpoint
├── service/RagService.java        # RAG orchestration
├── store/InMemoryVectorStore.java # Embedding + similarity search
└── model/AskRequest.java          # Request payload

---

## 🧪 Sample Request

```bash
curl -X POST http://localhost:8080/ask \
     -H "Content-Type: application/json" \
     -d '{"question":"What is Spring AI?"}'

Setup & Run Locally
Clone the repo

bash
git clone https://github.com/MakrandMZare/ragmak.git
cd ragmak
Configure API Key
Add to src/main/resources/application.properties:

properties
spring.ai.openai.api-key=YOUR_API_KEY
Run the app

bash
./mvnw spring-boot:run

Test the endpoint
Use Postman, curl, or browser extension to POST to /ask.